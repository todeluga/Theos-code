from flask import Flask, request, render_template
from flask_wtf import FlaskForm
from wtforms import StringField
from wtforms.validators import DataRequired
import csv
import re

# Set up Flask
app = Flask(__name__)
app.config['SECRET_KEY'] = 'change me to a random string'

# Create a class based on FlaskForm, for our movie search form
class MovieForm(FlaskForm):
    movie_title = StringField('movie_title', validators=[DataRequired()])

# Security: this is the function for the form/page to redirect to if special characters are input
# (it's an instance of our MovieForm class)
@app.route('/fail', methods=["POST"])
def back_to_the_beginning():
    fail_form = MovieForm() 
    return render_template('badinput.html', form=fail_form)

# This is the function for the form/page to redirect to if the searched content isn't found
# (it's an instance of our MovieForm class)
@app.route('/not_found', methods=["POST"])
def not_found():
    not_found_form = MovieForm()
    return render_template('not_found.html', form=not_found_form)

# The main function of the app
@app.route('/success', methods=["POST"])
def movie_information():

    # Access the data from the 'movies' CSV file
    movie_list = 'data/movies'
    
    # Create an instance of our MovieForm class
    movie_data = MovieForm()
    
    # Create a variable for the query string to go in the 'movie_search' search field
    movie_check = request.form['movie_search']
    
    # Security: create a regex object to capture special characters
    # and stop hackers from sending malicious code through the form
    # (if this was a real-world app, this is how an attacker might
    # corrupt data on the server)
    regex = re.compile('[@_!#$%^&*()<>?/\|}{~:]')
    
    # If the user enters special characters, redirect to the badinput page
    if regex.findall(movie_check):
        return render_template('badinput.html')

    # Create an initially empty dictionary object to store
    # the fields from the 'movies' CSV
    movies = dict()

    # Open the CSV file and read its contents
    with open(movie_list + '.csv') as f:
        reader = csv.DictReader(f)
        data = [r for r in reader]

        # Loop through all the fields from the CSV file
        # and place them into 'data' ('data' is a list object)
        for i in range(0, len(data)):

            # Move the now itemised fields from the 'data' list object
            # into the item spaces of the previously empty 'movies' dictionary object
            movies["Film"] = data[i]['Film']
            movies["Genre"] = data[i]['Genre']
            movies["Studio"] = data[i]['Studio']
            movies["Audience_score"] = data[i]['Audience_score']
            movies["Profitability"] = data[i]['Profitability']
            movies["Rotten_Tomatoes"] = data[i]['Rotten_Tomatoes']
            movies["Worldwide_Gross"] = data[i]['Worldwide_Gross']
            movies["Year"] = data[i]['Year']

        # Search the dictionary
            if movies["Film"] == str(movie_check):
            
        # Display the retrieved information if the search is successful
                return render_template('success.html', film=movies["Film"], genre=movies["Genre"],
                                       studio=movies["Studio"], score=movies["Audience_score"],
                                       profit=movies["Profitability"],
                                       rating=movies["Rotten_Tomatoes"], gross=movies["Worldwide_Gross"],
                                       year=movies["Year"],
                                       form=movie_data)
        # Otherwise, apologise for not finding it
        else:
            not_found()
            return render_template('not_found.html')

# This is the function for the apps search page
@app.route('/', methods=["GET", "POST"])
def search_movies():
    movie_input_form = MovieForm()
    return render_template('movies_form.html', form=movie_input_form)


if __name__ == "__main__":
    app.run(debug=True, port=5000)